package org.sid.serviceparking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class PaiementVente implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPaiementV;
    private Date datepaiementV;
    @OneToMany(mappedBy = "paiementVente",fetch = FetchType.LAZY)
    private Collection<CommandeVente> commandeVentes;
    @ManyToOne
    @JoinColumn(name = "idTypePaiement")
    private TypePaiement typePaiement;

}
