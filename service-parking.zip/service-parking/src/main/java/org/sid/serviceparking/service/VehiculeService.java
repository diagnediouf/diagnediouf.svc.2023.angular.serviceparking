package org.sid.serviceparking.service;

import java.util.Optional;

import org.sid.serviceparking.dao.VehiculeRepository;
import org.sid.serviceparking.entities.Vehicule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiculeService{
    @Autowired
    private VehiculeRepository vehiculeRepository;

    public Optional<Vehicule> findVehiculeById(String matricule){
        return vehiculeRepository.findById(matricule);
    }
}