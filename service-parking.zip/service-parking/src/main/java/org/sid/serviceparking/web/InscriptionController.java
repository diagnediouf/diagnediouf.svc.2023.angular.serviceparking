package org.sid.serviceparking.web;

import org.sid.serviceparking.entities.User;
import org.sid.serviceparking.service.InscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;


@RestController
public class InscriptionController {

    @Autowired
    private InscriptionService inscriptionService;

    @PostMapping("/inscription")
    @CrossOrigin("*")
    public User inscriptionUsers(@RequestBody User user)throws Exception {
        String tempEmailId = user.getEmailId();
        if(tempEmailId !=null && !"".equals(tempEmailId))
        {
            User userObj = inscriptionService.fetchUsersByEmailId(tempEmailId);
            if(userObj != null){
                throw new Exception("L'utilisateur avec \n"+tempEmailId+"\n existe dejas");
            }
        }
        User userObj = null;
        userObj = inscriptionService.saveUser(user);
        return userObj;
    }

    @PostMapping("/loginUser")
    @CrossOrigin("*")
    public User loginUser(@RequestBody User user) throws Exception{
        String tempEmailId = user.getEmailId();
        String tempPass = user.getPassworld();
        User userObj = null;
        if(tempEmailId != null && tempPass != null){
            userObj = inscriptionService.fetchUsersByEmailIdAndPassworld(tempEmailId, tempPass);
        }
        if(userObj == null)
        {
            throw new Exception("Cet Utilisateur n'existe pas, Inscrivez-vous");
        }
        return userObj;
    }
}
