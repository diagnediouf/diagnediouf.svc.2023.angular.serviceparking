package org.sid.serviceparking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Collection;
@Entity
@Data 
@NoArgsConstructor
@AllArgsConstructor 
@ToString
public class Vehicule implements Serializable {
    @Id
    private String matricule;
    private String marque;
    private String carburant;
    private String kilometrage;
    private String couleur;
    private Long nbrePlace;
    private Double currentprice;
    private Double prixParJour;
    private boolean promotion;
    private boolean selected;
    private boolean disponibilite;
    private String description;
    private String photoVeh;
    @Transient
    private int quantity=1;
    @OneToMany(mappedBy = "vehicule",fetch = FetchType.LAZY)
    private Collection<ReservationItem> reservationVehicules;
    @OneToMany(mappedBy = "vehicule",fetch = FetchType.LAZY)
    private Collection<CommandeItem> commandeVehicules;
    @ManyToOne
    @JoinColumn(name = "TYPE_VEH_ID")
    private TypeVehicule typeVehicule;
    @ManyToOne
    @JoinColumn(name = "NUM_PAIE_V")
    private PaiementVente paiementVente;
    @ManyToOne
    @JoinColumn(name = "NUM_PAIE_LOC")
    private PaiementLocation paiementLocation;
    @OneToMany(mappedBy = "vehicule",fetch = FetchType.LAZY)
    private Collection<Reglement> reglements;
    @ManyToOne
    @JoinColumn(name = "CODE_Comm_VENTE")
    private CommandeVente commandeVente;


}
