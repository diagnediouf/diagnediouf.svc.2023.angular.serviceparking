package org.sid.serviceparking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;



@Data @NoArgsConstructor @AllArgsConstructor @ToString
@Entity
public class ReservationLocation implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codeReservLoc;
    private Date dateDebutReserv;
    private Date dateFinReserv;
    private Double totalSomme;
    private String typeReservation;
    @ManyToOne
    @JoinColumn(name = "CIN_CLI")
    private Client client;
    @ManyToOne
    @JoinColumn(name = "NUM_PAIEMENT")
    private PaiementLocation paiementLocation;
    @OneToMany(mappedBy = "reservationLocation",fetch = FetchType.LAZY)
    private Collection<ReservationItem> reservationItems;

}
