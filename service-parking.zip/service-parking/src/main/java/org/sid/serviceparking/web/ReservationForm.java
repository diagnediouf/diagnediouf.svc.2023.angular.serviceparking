package org.sid.serviceparking.web;

import java.util.ArrayList;
import java.util.List;

import org.sid.serviceparking.entities.Client;

import lombok.Data;
@Data
public class ReservationForm {
    private Client client = new Client();
    private List<ReservationVehicule> reservehicules = new ArrayList<>();
}
@Data
class ReservationVehicule{
    private String matricule;
    private String marque;
    private int quantity;
    private Double prixParJour;
}
