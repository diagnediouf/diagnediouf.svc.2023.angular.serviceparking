package org.sid.serviceparking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class Reglement implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idReglement;
    private Date dateReglement;
    private String penalite;
    private Double montantReglement;
    private Date dateRetourVoiture;
    @ManyToOne
    @JoinColumn(name = "CNI_CLIENT")
    private Client client;
    @ManyToOne
    @JoinColumn(name = "Matricule_Veh")
    private Vehicule vehicule;
}
