package org.sid.serviceparking.web;

import java.util.Date;

import org.sid.serviceparking.dao.ClientRepository;
import org.sid.serviceparking.dao.ReservationItemRepository;
import org.sid.serviceparking.dao.ReservationLocationRepository;
import org.sid.serviceparking.dao.VehiculeRepository;
import org.sid.serviceparking.entities.Client;
import org.sid.serviceparking.entities.ReservationItem;
import org.sid.serviceparking.entities.ReservationLocation;
import org.sid.serviceparking.entities.Vehicule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("*")
@RestController
public class ReservationController {
    @Autowired
    private VehiculeRepository vehiculeRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private ReservationLocationRepository reservationLocRepository;
    @Autowired
    private ReservationItemRepository reservationItemRepository;

    @PostMapping(path = "/reservation")
    public ReservationLocation saveReservation(@RequestBody ReservationForm reservationForm){
        Client client = new Client();
        client.setCniClient(reservationForm.getClient().getCniClient());
        client.setNomClient(reservationForm.getClient().getNomClient());
        client.setPrenomClient(reservationForm.getClient().getPrenomClient());
        client.setPermitClient(reservationForm.getClient().getPermitClient());
        client.setAdresseClient(reservationForm.getClient().getAdresseClient());
        client.setTelClient(reservationForm.getClient().getTelClient());
        client.setMailClient(reservationForm.getClient().getMailClient());
        client.setAgeClient(reservationForm.getClient().getAgeClient());
        client.setUsername(reservationForm.getClient().getUsername());
        client=clientRepository.save(client);

        ReservationLocation reservationLoc=new ReservationLocation();
        reservationLoc.setClient(client);
        reservationLoc.setDateDebutReserv(new Date());
        reservationLoc.setDateFinReserv(new Date());
        reservationLoc.setTypeReservation(new String());
        reservationLoc=reservationLocRepository.save(reservationLoc);

        double total=0;
        for(ReservationVehicule resvehi:reservationForm.getReservehicules())
        {
            System.out.println(resvehi.getMatricule());
            ReservationItem reservationItem = new ReservationItem();
            reservationItem.setReservationLocation(reservationLoc);
            Vehicule vehicule = vehiculeRepository.findById(resvehi.getMatricule()).get();
            reservationItem.setVehicule(vehicule);
            reservationItem.setPrixParJour(vehicule.getPrixParJour());
            reservationItem.setQuantity(resvehi.getQuantity());
            reservationItemRepository.save(reservationItem);
            total+=resvehi.getQuantity()*vehicule.getPrixParJour();
        }
        reservationLoc.setTotalSomme(total);
        return reservationLocRepository.save(reservationLoc);
    }
    

}
