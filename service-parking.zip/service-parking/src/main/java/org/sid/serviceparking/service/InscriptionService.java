package org.sid.serviceparking.service;

import org.sid.serviceparking.dao.UserRepository;
import org.sid.serviceparking.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InscriptionService {

    @Autowired
    private UserRepository userRepo;
    public User saveUser(User user){
        return userRepo.save(user);
    }

    public User fetchUsersByEmailId(String emailId){
        return userRepo.findByEmailId(emailId);
    }

    public User fetchUsersByEmailIdAndPassworld(String email, String passworld){
        return userRepo.findByEmailIdAndPassworld(email, passworld);
    }
}