package org.sid.serviceparking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class PaiementLocation implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPaiementLoc;
    private Date datepaiementLoc;
    @ManyToOne
    @JoinColumn(name = "CNI_CLIENT")
    private Client client;
    @OneToMany(mappedBy = "paiementLocation",fetch = FetchType.LAZY)
    private Collection<ReservationLocation> reservationLocations;
    @OneToMany(mappedBy = "paiementLocation",fetch = FetchType.LAZY)
    private Collection<Vehicule> vehicules;
    @ManyToOne
    @JoinColumn(name = "idTypePaiement")
    private TypePaiement typePaiement;

    public PaiementLocation(Date datepaiementLoc, Client client) {
        this.datepaiementLoc = datepaiementLoc;
        this.client = client;
    }
}
